"""Session-scoped LLM switching. Only server-side, allowlisted configs are used."""
import httpx
from loguru import logger

from .agent.agent_factory import AgentFactory


PROFILES = {
    "deepseek-flash": ("deepseek_llm", "DeepSeek Flash"),
    "qwen-local": ("openai_compatible_llm", "本地 Qwen3.5 4B · Int4"),
}


def llm_state(context):
    config = context.character_config.agent_config
    selected_provider = config.agent_settings.basic_memory_agent.llm_provider
    options = []
    selected = None
    for profile, (provider, label) in PROFILES.items():
        entry = getattr(config.llm_configs, provider, None)
        if entry is not None:
            options.append({"id": profile, "label": label, "model": entry.model})
        if provider == selected_provider:
            selected = profile
    # Never serialize config objects, endpoints, API keys, or agent memory here.
    return {"type": "llm-state", "llm_profile": selected, "llm_profiles": options}


async def close_agent(agent):
    client = getattr(getattr(agent, "_llm", None), "client", None)
    if client is not None:
        try:
            await client.close()
        except Exception as error:
            logger.warning("Closing old LLM client failed: {}", type(error).__name__)


async def build_agent(context, config):
    system_prompt = await context.construct_system_prompt(
        context.character_config.persona_prompt
    )
    agent = AgentFactory.create_agent(
        conversation_agent_choice=config.conversation_agent_choice,
        agent_settings=config.agent_settings.model_dump(),
        llm_configs=config.llm_configs.model_dump(),
        system_prompt=system_prompt,
        live2d_model=context.live2d_model,
        tts_preprocessor_config=context.character_config.tts_preprocessor_config,
        character_avatar=context.character_config.avatar or "",
        system_config=context.system_config.model_dump(),
        tool_manager=context.tool_manager,
        tool_executor=context.tool_executor,
        mcp_prompt_string=context.mcp_prompt,
    )
    return agent, system_prompt


async def isolate_session_agent(context):
    """The original cache shares the agent; clone it before any client history loads."""
    config = context.character_config.agent_config
    if config.conversation_agent_choice == "basic_memory_agent":
        context.agent_engine, context.system_prompt = await build_agent(context, config)


async def switch_llm(context, profile):
    if profile not in PROFILES:
        raise ValueError("不支持的模型选项。")
    original = context.character_config.agent_config
    if original.conversation_agent_choice != "basic_memory_agent":
        raise ValueError("当前智能体不支持此切换入口。")
    provider, _ = PROFILES[profile]
    entry = getattr(original.llm_configs, provider, None)
    if entry is None:
        raise ValueError("该模型尚未配置。")
    if profile == "qwen-local":
        # Local availability is checked BEFORE committing any state change.
        try:
            async with httpx.AsyncClient(trust_env=False, timeout=4) as client:
                response = await client.get(entry.base_url.rstrip("/") + "/models")
                response.raise_for_status()
                model_ids = {model["id"] for model in response.json().get("data", [])}
            if entry.model not in model_ids:
                raise ValueError("本地模型名称不匹配，原模型已保留。")
        except (httpx.HTTPError, KeyError, TypeError, ValueError) as error:
            raise ValueError("本地 Qwen 服务未就绪或模型不匹配，原模型已保留。") from error
    if original.agent_settings.basic_memory_agent.llm_provider == provider:
        return
    updated = original.model_copy(deep=True)
    updated.agent_settings.basic_memory_agent.llm_provider = provider
    candidate, system_prompt = await build_agent(context, updated)
    try:
        if context.history_uid:
            candidate.set_memory_from_history(
                context.character_config.conf_uid, context.history_uid
            )
    except Exception:
        await close_agent(candidate)
        raise
    previous = context.agent_engine
    context.agent_engine = candidate
    context.system_prompt = system_prompt
    context.character_config.agent_config = updated
    context.config.character_config.agent_config = updated.model_copy(deep=True)
    await close_agent(previous)
    logger.info("Session {} selected LLM {}", context.client_uid, profile)

