"""Configure a fresh A1 checkout without echoing API keys or replacing other settings."""
import argparse
from datetime import datetime
import getpass
import io
import os
from pathlib import Path
import shutil
import sys

from ruamel.yaml import YAML

parser = argparse.ArgumentParser()
parser.add_argument('--project', default='/data/Open-LLM-VTuber')
parser.add_argument('--default', choices=['deepseek-flash', 'qwen-local'], default='deepseek-flash')
parser.add_argument('--local-max-tokens', type=int, default=128)
parser.add_argument('--keep-key', action='store_true', help='保留已有 Key，不提示输入；用于自动化干跑')
args = parser.parse_args()
if not 1 <= args.local_max_tokens <= 512:
    raise SystemExit('local-max-tokens 必须在 1 到 512 之间。')
project = Path(args.project).resolve()
sys.path.insert(0, str(project))
path = project / 'conf.yaml'
template = project / 'config_templates/conf.ZH.default.yaml'
yaml = YAML()
yaml.preserve_quotes = True
data = yaml.load(path.read_text() if path.exists() else template.read_text())
system = data['system_config']
system.update(host='localhost', port=12393)
character = data['character_config']
character['live2d_model_name'] = 'mao_pro'
agent = character['agent_config']
agent['conversation_agent_choice'] = 'basic_memory_agent'
settings = agent['agent_settings']['basic_memory_agent']
settings['llm_provider'] = 'deepseek_llm' if args.default == 'deepseek-flash' else 'openai_compatible_llm'
settings['use_mcpp'] = False
cloud = agent['llm_configs']['deepseek_llm']
if not args.keep_key and not sys.stdin.isatty():
    raise SystemExit('请在交互式 SSH 终端运行，以隐藏 Key 输入；自动检查请使用 --keep-key。')
key = '' if args.keep_key else getpass.getpass('DeepSeek API Key（隐藏输入；留空保留已有值）：').strip()
if key:
    cloud['llm_api_key'] = key
cloud.update(model='deepseek-flash', temperature=0.7, extra_body={'thinking': {'type': 'disabled'}})
local = agent['llm_configs']['openai_compatible_llm']
local.update(base_url='http://127.0.0.1:18080/v1', llm_api_key='local',
             model='Qwen3.5-4B-AX8850-Int4', temperature=0.7,
             extra_body={'enable_thinking': False, 'max_tokens': args.local_max_tokens})
models = [project / 'models/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17',
          project / 'models/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17']
model = next((p for p in models if (p / 'model.int8.onnx').is_file() and (p / 'tokens.txt').is_file()), None)
if model is None:
    raise SystemExit('请先下载 SenseVoice int8 模型；配置尚未写入。')
asr = character['asr_config']
asr['asr_model'] = 'sherpa_onnx_asr'
asr['sherpa_onnx_asr'].update(model_type='sense_voice',
    sense_voice='./' + (model / 'model.int8.onnx').relative_to(project).as_posix(),
    tokens='./' + (model / 'tokens.txt').relative_to(project).as_posix(),
    num_threads=4, use_itn=True, provider='cpu')
tts = character['tts_config']
tts['tts_model'] = 'edge_tts'
tts['edge_tts']['voice'] = 'zh-CN-XiaoxiaoNeural'
vad = character['vad_config']
vad['vad_model'] = 'silero_vad'
vad['silero_vad'].update(orig_sr=16000, target_sr=16000, prob_threshold=0.4,
    db_threshold=60, required_hits=3, required_misses=24, smoothing_window=5)
buffer = io.StringIO()
yaml.dump(data, buffer)
from src.open_llm_vtuber.config_manager import validate_config
try:
    validate_config(YAML(typ='safe').load(buffer.getvalue()))
except Exception:
    raise SystemExit('配置校验失败；未写入文件。详细输入未输出，以免泄露 API Key。') from None
if path.exists():
    backup = Path('/data/vtuber-backups') / (datetime.now().strftime('%Y%m%d-%H%M%S') + '-config')
    backup.mkdir(mode=0o700, parents=True)
    shutil.copy2(path, backup / 'conf.yaml')
    (backup / 'conf.yaml').chmod(0o600)
    print('配置备份：', backup)
temp = path.with_name('conf.yaml.a1-new')
fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, 'w', encoding='utf-8') as output:
    output.write(buffer.getvalue())
os.replace(temp, path)
print('CONFIG_OK；默认模型：', args.default, '；本地回复上限：', args.local_max_tokens)
print('API Key 未输出。人物性格保持原配置，可稍后自行调整。')
