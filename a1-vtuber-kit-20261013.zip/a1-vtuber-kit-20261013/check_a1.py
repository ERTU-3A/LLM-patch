"""Read-only ONNX/ASR/VAD checks. No Torch import and no cloud API request."""
import argparse
from pathlib import Path
import sys
import numpy as np
import soundfile as sf
import onnxruntime as ort
import sherpa_onnx

parser = argparse.ArgumentParser()
parser.add_argument('--project', default='/data/Open-LLM-VTuber')
parser.add_argument('--speech', action='store_true', help='Also load CPU ASR/VAD and test the bundled sample')
args = parser.parse_args()
project = Path(args.project).resolve()
sys.path.insert(0, str(project))
from src.open_llm_vtuber.config_manager import read_yaml, validate_config
config = validate_config(read_yaml(str(project / 'conf.yaml')))
agent = config.character_config.agent_config
print('PYTHON', sys.version.split()[0])
print('CPU_ONNX_PROVIDER', 'CPUExecutionProvider' in ort.get_available_providers())
print('LLM_DEFAULT', agent.agent_settings.basic_memory_agent.llm_provider)
print('LLM_LOCAL_MODEL', agent.llm_configs.openai_compatible_llm.model)
print('ASR', config.character_config.asr_config.asr_model)
if args.speech:
    raw = config.character_config.asr_config.sherpa_onnx_asr
    model = (project / raw.sense_voice).resolve()
    tokens = (project / raw.tokens).resolve()
    sample = model.parent / 'test_wavs/zh.wav'
    audio, rate = sf.read(sample, dtype='float32')
    if audio.ndim != 1 or rate != 16000:
        raise SystemExit('测试样本必须是 16kHz 单声道 WAV。')
    recognizer = sherpa_onnx.OfflineRecognizer.from_sense_voice(
        model=str(model), tokens=str(tokens), num_threads=4, use_itn=True, provider='cpu')
    stream = recognizer.create_stream()
    stream.accept_waveform(rate, audio)
    recognizer.decode_stream(stream)
    if not stream.result.text:
        raise SystemExit('ASR 没有输出。')
    print('ASR_SAMPLE_RESULT', stream.result.text)
    from src.open_llm_vtuber.vad.silero import VADEngine
    vad = VADEngine(**config.character_config.vad_config.silero_vad.model_dump())
    data = np.concatenate((np.zeros(16000, dtype=np.float32), audio, np.zeros(32000, dtype=np.float32)))
    results = list(vad.detect_speech(data.tolist()))
    chunks = sum(isinstance(value, bytes) and len(value) > 1024 for value in results)
    if not chunks:
        raise SystemExit('VAD 未检测到测试样本中的语音。')
    print('VAD_SPEECH_CHUNKS', chunks)
print('A1_CHECK_OK')
