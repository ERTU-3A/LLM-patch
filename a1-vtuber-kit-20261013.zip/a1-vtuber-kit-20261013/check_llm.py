"""Explicit short LLM tests; API credentials are read privately from conf.yaml."""
import argparse
from pathlib import Path
import httpx
from openai import OpenAI, APIStatusError
import yaml

parser=argparse.ArgumentParser()
parser.add_argument('--project',default='/data/Open-LLM-VTuber')
mode=parser.add_mutually_exclusive_group(required=True)
mode.add_argument('--local',action='store_true')
mode.add_argument('--cloud',action='store_true',help='Calls DeepSeek and consumes a small number of API tokens')
parser.add_argument('--stream',action='store_true')
args=parser.parse_args()
config=yaml.safe_load((Path(args.project)/'conf.yaml').read_text())
configs=config['character_config']['agent_config']['llm_configs']
entry=configs['openai_compatible_llm' if args.local else 'deepseek_llm']
base=entry['base_url'] if args.local else 'https://api.deepseek.com'
try:
    with OpenAI(base_url=base,api_key=entry['llm_api_key'],max_retries=0,
                http_client=httpx.Client(trust_env=False,timeout=90)) as client:
        result=client.chat.completions.create(model=entry['model'],
            messages=[{'role':'user','content':'请只回复：测试通过。'}],
            max_tokens=32,stream=args.stream,temperature=0.3,
            extra_body={'enable_thinking':False} if args.local else {'thinking':{'type':'disabled'}})
        print('MODEL',entry['model'])
        if args.stream:
            for chunk in result:
                if chunk.choices and chunk.choices[0].delta.content:
                    print(chunk.choices[0].delta.content,end='',flush=True)
            print()
        else:
            print(result.choices[0].message.content)
    print('LLM_CHECK_OK')
except APIStatusError as error:
    raise SystemExit('LLM_HTTP_ERROR '+str(error.status_code)+'；未输出请求或 Key。') from None
except Exception as error:
    raise SystemExit('LLM_CHECK_FAILED '+type(error).__name__+'；检查服务、网络和模型名。') from None
