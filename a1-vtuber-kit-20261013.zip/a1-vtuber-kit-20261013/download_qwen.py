"""Download a pinned public AXERA snapshot; resume and verify all model files.

Artifact downloads use a separate directory, not the VTuber virtualenv/cache.
"""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import threading
import time

import requests

REPO = "AXERA-TECH/Qwen3.5-4B-AX650-GPTQ-Int4-C256-P10K-CTX12K"
REVISION = "3d0723b1e9928bf56a8932f3d8ad4d88fe0b9ba9"
DEST = Path("/data/models/AXERA-TECH") / REPO.split("/")[1]
PROXY = {"http": "http://127.0.0.1:17895", "https": "http://127.0.0.1:17895"}
LOCK = threading.Lock()
START = time.monotonic()
COMPLETED = 0


def session():
    result = requests.Session()
    result.trust_env = False
    result.proxies.update(PROXY)
    return result


def verify(path, entry):
    if path.stat().st_size != entry["size"]:
        return False
    digest = hashlib.sha256() if entry.get("lfs") else hashlib.sha1()
    if not entry.get("lfs"):
        digest.update(f"blob {entry['size']}\0".encode())
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    expected = entry["lfs"]["sha256"] if entry.get("lfs") else entry["blobId"]
    return digest.hexdigest() == expected


def fetch(entry):
    global COMPLETED
    name = entry["rfilename"]
    if "/" in name or name in (".", ".."):
        raise ValueError("Unexpected artifact filename")
    path = DEST / name
    partial = DEST / (name + ".partial")
    if path.exists():
        if not verify(path, entry):
            raise RuntimeError(f"Existing artifact checksum mismatch: {name}")
    else:
        for attempt in range(8):
            offset = partial.stat().st_size if partial.exists() else 0
            if offset > entry["size"]:
                raise RuntimeError(f"Partial artifact too large: {name}")
            if offset == entry["size"]:
                if not verify(partial, entry):
                    raise RuntimeError(f"Checksum mismatch: {name}")
                partial.rename(path)
                break
            try:
                with session() as client:
                    headers = {"Range": f"bytes={offset}-"} if offset else {}
                    with client.get(f"https://huggingface.co/{REPO}/resolve/{REVISION}/{name}", headers=headers, stream=True, timeout=(15, 45)) as response:
                        response.raise_for_status()
                        if offset and response.status_code != 206:
                            raise RuntimeError("Server did not honor resume range")
                        with partial.open("ab" if offset else "wb") as stream:
                            for chunk in response.iter_content(1024 * 1024):
                                stream.write(chunk)
                if not verify(partial, entry):
                    raise RuntimeError(f"Checksum mismatch: {name}")
                partial.rename(path)
                break
            except requests.RequestException as error:
                print("RETRY", name, attempt + 1, type(error).__name__, flush=True)
                time.sleep(min(2 * (attempt + 1), 10))
        else:
            raise RuntimeError(f"Download exhausted retries: {name}")
    with LOCK:
        COMPLETED += entry["size"]
        elapsed = time.monotonic() - START
        print("VERIFIED", name, "bytes", entry["size"], "total_MiB", round(COMPLETED / 1048576), "elapsed_s", round(elapsed), flush=True)


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    with session() as client:
        response = client.get(f"https://huggingface.co/api/models/{REPO}/revision/{REVISION}?blobs=true", timeout=20)
        response.raise_for_status()
        info = response.json()
    assert info["sha"] == REVISION
    files = [entry for entry in info["siblings"] if "/" not in entry["rfilename"] and not entry["rfilename"].startswith(".")]
    # Runtime metadata has no credentials; this manifest fixes exact provenance.
    manifest = {"repo": REPO, "revision": REVISION, "files": files}
    (DEST / "download-manifest.json").write_text(json.dumps(manifest, indent=2))
    print("DOWNLOAD_START", REPO, REVISION, "files", len(files), "bytes", sum(e["size"] for e in files), flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(fetch, files))
    print("DOWNLOAD_COMPLETE_ALL_CHECKSUMS_OK", DEST, flush=True)


if __name__ == "__main__":
    main()
