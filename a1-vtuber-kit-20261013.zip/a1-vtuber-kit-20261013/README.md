# A1 VTuber 适配与双 LLM 切换补丁包

日期：2026-10-13。完整部署、使用和排障指南在本次对话正文。

仅用于 Ubuntu 24.04 / aarch64、DShanPi-A1、AX8850、AXCL 3.16。
后端基线：`992309c0aa19845960228f880013d4685fde93b5`；项目声明版本 1.2.1。
前端源码基线：`3d57a9a0125a0ca13e5d096f7092e4e494ed389e`。
此包不是官方发布的完整系统镜像，也不是项目官方新增的切换功能。

## 内容

- `backend.patch`、`llm_switch.py`：ARM ONNX VAD、仅 TTS 代理、extra_body、会话级双 LLM 切换。
- `frontend-web.tar.gz`：已经构建的网页，含切换按钮；安装时保留旧文件和 `.git`。
- `frontend-source-overlay.tar.gz`：前端增量源码；覆盖到对应官方源码提交后才可构建。
- `requirements-a1.txt`：实际部署的依赖版本快照，**使用 --no-deps 安装**；有意省略 Torch。
- `configure_a1.py`：隐藏输入 API Key，设置模块并验证配置；不包含任何预置 Key。
- `download_qwen.py`：下载固定官方模型版本、断点续传和文件校验；需本机 17895 下载代理。
- `setup_qwen.py`、`qwen-runtime-config.json`：创建独立运行目录和符号链接，不改原模型快照。
- `axllm`：官方 AXCL/Linux arm64 运行程序，固定哈希；不含驱动和约 6 GB 模型权重。
- 两个 `.service` 文件：启动配置样例，使用 root 和固定 `/data` 路径。
- VTuber 服务模板额外加入 SD 卡目录的挂载依赖；不会修改当前已部署服务。
- `check_a1.py`：不调用云 API 的 CPU ASR/VAD 样本检查。
- `SHA256SUMS`、`provenance.json`：内容校验及来源。

`install_overlay.sh` **只适用于全新、无源码改动的官方基线工程**。已部署的 A1 不要重复运行。
安装脚本不修改网络、格式化 SD 卡、安装包、填写 Key 或启动服务。
可先执行 `bash install_overlay.sh /data/Open-LLM-VTuber --check`，只进行版本和补丁干跑检查。
依赖清单省略 Torch，因此 `pip check` 可能报告可选后端缺少 Torch；本指南限定 ONNX ASR/VAD 路径。
这不是全后端兼容承诺。切换到 Whisper/FunASR 等其他模块时应重新评估依赖和 ARM 支持。

## 来源和许可

- 后端：https://github.com/Open-LLM-VTuber/Open-LLM-VTuber
- 前端：https://github.com/Open-LLM-VTuber/Open-LLM-VTuber-Web
- AXCL 运行程序：https://github.com/AXERA-TECH/ax-llm/tree/axllm
- 模型：https://huggingface.co/AXERA-TECH/Qwen3.5-4B-AX650-GPTQ-Int4-C256-P10K-CTX12K
- SenseVoice：https://k2-fsa.github.io/sherpa/onnx/sense-voice/pretrained.html

保留并遵守上游 LICENSE。网页中包含 Live2D/ONNX Runtime/Silero 等上游资源，
各自许可与使用条件不因本补丁改变；请勿将教学验证包视为商业再分发授权。
