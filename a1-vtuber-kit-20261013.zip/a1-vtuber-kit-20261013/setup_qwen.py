"""Prepare the AXCL runtime overlay without modifying the downloaded snapshot."""
import json
from pathlib import Path
import shutil

kit = Path(__file__).resolve().parent
source = Path('/data/models/AXERA-TECH/Qwen3.5-4B-AX650-GPTQ-Int4-C256-P10K-CTX12K')
destination = Path('/data/ax-llm/models/qwen3.5-4b-int4')
manifest = json.loads((source / 'download-manifest.json').read_text())
if manifest['revision'] != '3d0723b1e9928bf56a8932f3d8ad4d88fe0b9ba9':
    raise SystemExit('模型版本与此配置不一致，停止。')
entries = [entry for entry in manifest['files'] if entry['rfilename'] != 'config.json'
           and entry['rfilename'].endswith(('.axmodel', '.bin', '.txt', '.json'))]
for entry in entries:
    file = source / entry['rfilename']
    if not file.is_file() or file.stat().st_size != entry['size']:
        raise SystemExit('模型文件缺失或大小错误：' + file.name)
destination.mkdir(parents=True, exist_ok=True)
for entry in entries:
    file = source / entry['rfilename']
    target = destination / file.name
    if target.exists() or target.is_symlink():
        if not target.is_symlink() or target.resolve() != file.resolve():
            raise SystemExit('不覆盖已有不同文件：' + str(target))
    else:
        target.symlink_to(file)
config = destination / 'config.json'
expected = (kit / 'qwen-runtime-config.json').read_bytes()
if config.exists() and config.read_bytes() != expected:
    raise SystemExit('已有不同的运行配置，不覆盖：' + str(config))
if not config.exists():
    shutil.copy2(kit / 'qwen-runtime-config.json', config)
print('QWEN_RUNTIME_OVERLAY_OK', destination)
