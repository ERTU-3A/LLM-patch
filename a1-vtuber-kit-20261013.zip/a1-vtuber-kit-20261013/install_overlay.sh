#!/usr/bin/env bash
# Apply only to the clean, pinned official checkout. No packages/services are changed.
set -euo pipefail
kit_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
project_dir="${1:-/data/Open-LLM-VTuber}"
expected_commit="992309c0aa19845960228f880013d4685fde93b5"
test -d "$project_dir/.git" || { echo '缺少官方 Git 工程，停止。'; exit 1; }
test "$(git -C "$project_dir" rev-parse HEAD)" = "$expected_commit" || {
    echo '项目提交与补丁不匹配；请勿强行应用。'; exit 1;
}
git -C "$project_dir" diff --quiet -- src/open_llm_vtuber || {
    echo '源码已有修改。此脚本只用于全新部署，不覆盖已部署的 A1。'; exit 1;
}
test ! -e "$project_dir/src/open_llm_vtuber/llm_switch.py" || {
    echo '切换模块已存在，请勿重复安装。'; exit 1;
}
test -f "$project_dir/frontend/index.html" || {
    echo '缺少前端子模块，请先执行 git submodule update --init --recursive。'; exit 1;
}
patch --directory="$project_dir" --batch --forward --dry-run -p1 < "$kit_dir/backend.patch"
if test "${2:-}" = '--check'; then
    echo 'OVERLAY_DRY_RUN_OK；未修改项目。'
    exit 0
fi
if systemctl is-active --quiet open-llm-vtuber.service; then
    echo '已有 VTuber 服务运行。请使用已部署设备的快速体验流程，不运行首次安装脚本。'
    exit 1
fi
backup_dir="/data/vtuber-backups/$(date +%Y%m%d-%H%M%S)-overlay"
install -d -m 700 "$backup_dir"
cp -a "$project_dir/src" "$backup_dir/src"
cp -a "$project_dir/frontend" "$backup_dir/frontend"
if test -f "$project_dir/conf.yaml"; then
    cp -a "$project_dir/conf.yaml" "$backup_dir/conf.yaml"
    chmod 600 "$backup_dir/conf.yaml"
fi
patch --directory="$project_dir" --batch --forward -p1 < "$kit_dir/backend.patch"
install -m 644 "$kit_dir/llm_switch.py" "$project_dir/src/open_llm_vtuber/llm_switch.py"
tar -xzf "$kit_dir/frontend-web.tar.gz" -C "$project_dir/frontend" --strip-components=1
echo "适配和切换按钮已安装。备份：$backup_dir"
echo '尚未安装 Python 依赖、下载模型、填写 API Key 或启动服务，请继续指南。'
