import json
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, Mock, patch

import httpx

from src.open_llm_vtuber import llm_switch
from src.open_llm_vtuber.config_manager import read_yaml, validate_config
from src.open_llm_vtuber.websocket_handler import WebSocketHandler


class LLMSwitchTests(unittest.IsolatedAsyncioTestCase):
    def make_context(self):
        config = validate_config(read_yaml("conf.yaml")).model_copy(deep=True)
        config.character_config.agent_config.agent_settings.basic_memory_agent.llm_provider = "deepseek_llm"
        context = SimpleNamespace(
            config=config,
            character_config=config.character_config.model_copy(deep=True),
            agent_engine=SimpleNamespace(_llm=SimpleNamespace(client=SimpleNamespace(close=AsyncMock()))),
            system_prompt="old prompt", history_uid="existing-history", client_uid="test-client",
        )
        return context

    def local_response(self, context):
        name = context.character_config.agent_config.llm_configs.openai_compatible_llm.model
        response = Mock()
        response.json.return_value = {"data": [{"id": name}]}
        client = AsyncMock()
        client.__aenter__.return_value = client
        client.get.return_value = response
        return client

    async def test_unknown_profile_preserves_original_agent(self):
        context = self.make_context()
        old = context.agent_engine
        with self.assertRaises(ValueError):
            await llm_switch.switch_llm(context, "http://unexpected-endpoint")
        self.assertIs(context.agent_engine, old)

    async def test_offline_local_preserves_original_selection(self):
        context = self.make_context()
        old = context.agent_engine
        client = self.local_response(context)
        client.get.side_effect = httpx.ConnectError("offline")
        with patch.object(llm_switch.httpx, "AsyncClient", return_value=client):
            with self.assertRaises(ValueError):
                await llm_switch.switch_llm(context, "qwen-local")
        self.assertIs(context.agent_engine, old)
        self.assertEqual(llm_switch.llm_state(context)["llm_profile"], "deepseek-flash")
        old._llm.client.close.assert_not_awaited()

    async def test_switch_preserves_history_and_isolates_config(self):
        first = self.make_context()
        second = self.make_context()
        old = first.agent_engine
        candidate = Mock()
        client = self.local_response(first)
        with patch.object(llm_switch.httpx, "AsyncClient", return_value=client), patch.object(llm_switch, "build_agent", AsyncMock(return_value=(candidate, "new prompt"))):
            await llm_switch.switch_llm(first, "qwen-local")
        candidate.set_memory_from_history.assert_called_once_with(first.character_config.conf_uid, "existing-history")
        self.assertIs(first.agent_engine, candidate)
        self.assertEqual(llm_switch.llm_state(first)["llm_profile"], "qwen-local")
        self.assertEqual(llm_switch.llm_state(second)["llm_profile"], "deepseek-flash")
        old._llm.client.close.assert_awaited_once()

    async def test_history_failure_does_not_commit_switch(self):
        context = self.make_context()
        old = context.agent_engine
        candidate = Mock()
        candidate.set_memory_from_history.side_effect = RuntimeError("invalid history")
        client = self.local_response(context)
        with patch.object(llm_switch.httpx, "AsyncClient", return_value=client), patch.object(llm_switch, "build_agent", AsyncMock(return_value=(candidate, "new prompt"))), patch.object(llm_switch, "close_agent", AsyncMock()) as close:
            with self.assertRaises(RuntimeError):
                await llm_switch.switch_llm(context, "qwen-local")
        self.assertIs(context.agent_engine, old)
        close.assert_awaited_once_with(candidate)

    async def test_cloud_selection_requires_no_local_connection(self):
        context = self.make_context()
        context.character_config.agent_config.agent_settings.basic_memory_agent.llm_provider = "openai_compatible_llm"
        candidate = Mock()
        with patch.object(llm_switch.httpx, "AsyncClient") as local, patch.object(llm_switch, "build_agent", AsyncMock(return_value=(candidate, "prompt"))):
            await llm_switch.switch_llm(context, "deepseek-flash")
        local.assert_not_called()
        self.assertEqual(llm_switch.llm_state(context)["llm_profile"], "deepseek-flash")

    async def test_state_contains_no_api_key_or_endpoint(self):
        state = json.dumps(llm_switch.llm_state(self.make_context()))
        self.assertNotIn("sk-", state)
        self.assertNotIn("llm_api_key", state)
        self.assertNotIn("base_url", state)

    async def test_busy_conversation_rejects_switch(self):
        context = self.make_context()
        handler = WebSocketHandler.__new__(WebSocketHandler)
        handler.client_contexts = {"test": context}
        handler.current_conversation_tasks = {"test": SimpleNamespace(done=lambda: False)}
        websocket = SimpleNamespace(send_text=AsyncMock())
        with patch("src.open_llm_vtuber.websocket_handler.switch_llm", AsyncMock()) as switch:
            await handler._handle_llm_switch(websocket, "test", {"llm_profile": "qwen-local"})
        switch.assert_not_awaited()
        result = json.loads(websocket.send_text.call_args.args[0])
        self.assertEqual(result["type"], "llm-switch-error")


if __name__ == "__main__":
    unittest.main(verbosity=2)
